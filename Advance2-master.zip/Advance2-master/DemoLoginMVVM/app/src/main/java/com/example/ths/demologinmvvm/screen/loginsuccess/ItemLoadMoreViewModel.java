package com.example.ths.demologinmvvm.screen.loginsuccess;

import android.databinding.BaseObservable;
import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by ths on 19/05/2017.
 */

public class ItemLoadMoreViewModel extends BaseObservable {

    public ItemLoadMoreViewModel() {
    }
}
