package com.example.ths.demologinmvvm.utils;

/**
 * Created by ths on 17/05/2017.
 */

public final class Constant {
    private Constant() {
    }
    public static final String KEY_BUNDLE = "OBJECT_DATA";
    public static final String KEY_SHARED = "SHARE_KEY";
    public static final String KEY_TOKEN = "SHARE_TOKEN";
    public static final String KEY_CHECK = "SHARE_CHECK";
}
