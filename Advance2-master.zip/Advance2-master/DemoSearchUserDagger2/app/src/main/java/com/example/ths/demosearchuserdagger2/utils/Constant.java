package com.example.ths.demosearchuserdagger2.utils;

/**
 * Created by ths on 23/05/2017.
 */

public class Constant {
    public static final String END_POINT_URL="https://api.github.com";
    public static final String KEY_BUNDLE="KEY_BUNDLE";
}
