package com.example.ths.demologinmvvm.screen.loginsuccess;

/**
 * Created by ths on 18/05/2017.
 */

public interface OnLoadMoreListener {
    void onLoadMore();
    void onStopLoadMore();
}
