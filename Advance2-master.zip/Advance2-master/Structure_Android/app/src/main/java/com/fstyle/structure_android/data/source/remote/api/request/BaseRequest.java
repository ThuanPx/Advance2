package com.fstyle.structure_android.data.source.remote.api.request;

import com.fstyle.structure_android.data.model.BaseModel;

/**
 * Created by le.quang.dao on 10/03/2017.
 */

public abstract class BaseRequest extends BaseModel {
}
