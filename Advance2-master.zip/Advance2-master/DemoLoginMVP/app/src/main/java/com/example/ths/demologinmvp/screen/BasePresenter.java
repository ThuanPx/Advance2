package com.example.ths.demologinmvp.screen;

import android.content.Context;

/**
 * Created by ths on 12/05/2017.
 */

public interface BasePresenter<T> {
    void setView(T view);



}
