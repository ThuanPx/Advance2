package com.fstyle.structure_android.screen.test;

import com.fstyle.structure_android.screen.BaseViewModel;
import com.fstyle.structure_android.utils.rx.BaseSchedulerProvider;

/**
 * Exposes the data to be used in the Test screen.
 */

public class TestViewModel extends BaseViewModel {

    @Override
    public void setSchedulerProvider(BaseSchedulerProvider schedulerProvider) {

    }
}
