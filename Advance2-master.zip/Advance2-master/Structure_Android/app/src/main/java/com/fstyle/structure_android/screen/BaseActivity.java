package com.fstyle.structure_android.screen;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by le.quang.dao on 10/03/2017.
 */

public class BaseActivity extends AppCompatActivity {
}
