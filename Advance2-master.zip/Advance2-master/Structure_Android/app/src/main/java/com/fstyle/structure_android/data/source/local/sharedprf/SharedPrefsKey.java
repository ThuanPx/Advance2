package com.fstyle.structure_android.data.source.local.sharedprf;

/**
 * Created by le.quang.dao on 14/03/2017.
 */

public final class SharedPrefsKey {

    private SharedPrefsKey() {
        // No-op
    }

}
