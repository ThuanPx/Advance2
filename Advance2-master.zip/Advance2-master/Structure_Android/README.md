# Structure_Android
Follow android-mvvm-architecture: [googlesamples](https://github.com/googlesamples/android-architecture/tree/dev-todo-mvvm-databinding)
<img src="https://github.com/googlesamples/android-architecture/wiki/images/mvvm-databinding.png" alt="Diagram"/>
# Templates
Template MVVM Activity & MVVM Fragment: [Template](https://github.com/daolq3012/Structure_Android/blob/mvvm-architecture/templates/MVVM_templates.zip?raw=true)
