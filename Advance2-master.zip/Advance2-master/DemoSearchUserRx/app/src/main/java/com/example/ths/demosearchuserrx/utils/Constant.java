package com.example.ths.demosearchuserrx.utils;

/**
 * Created by ths on 21/05/2017.
 */

public final class Constant {
    private Constant() {
    }
    public static final String END_POINT_URL = "https://api.github.com";
    public static final String KEY_BUNDLE ="KEY_LIST";
}
