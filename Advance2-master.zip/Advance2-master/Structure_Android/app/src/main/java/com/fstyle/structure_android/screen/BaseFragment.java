package com.fstyle.structure_android.screen;

import android.support.v4.app.Fragment;

/**
 * Created by Sun on 3/11/2017.
 */

public class BaseFragment extends Fragment {
}
