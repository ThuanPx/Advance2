package com.example.ths.demosearchuserdagger2.screen.searchresult;

/**
 * Created by ths on 23/05/2017.
 */

public interface SearchResultContract {

    interface View {

    }
    interface  Presenter{

    }
}
