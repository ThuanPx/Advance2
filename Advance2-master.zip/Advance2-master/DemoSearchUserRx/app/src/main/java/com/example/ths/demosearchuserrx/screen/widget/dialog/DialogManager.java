package com.example.ths.demosearchuserrx.screen.widget.dialog;

/**
 * Created by ths on 19/05/2017.
 */

public interface DialogManager {
    void showProgress();
    void hideDProgress();
}
