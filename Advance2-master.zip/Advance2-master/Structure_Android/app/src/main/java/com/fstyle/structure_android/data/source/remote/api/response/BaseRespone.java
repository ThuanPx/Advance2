package com.fstyle.structure_android.data.source.remote.api.response;

/**
 * Created by le.quang.dao on 10/03/2017.
 */

public abstract class BaseRespone {
}
